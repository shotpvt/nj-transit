"""Run the River LINE timetable model.

    python run.py                         # base config (8 LRVs)
    python run.py --fleet 6 7 8 9 10      # one scenario per fleet size
    python run.py --config my_case.yaml --name track_work

Writes outputs/<name>/timetable.csv, vehicle_blocks.csv, summary.json and
outputs/comparison.csv (with NJ TRANSIT's 2013 and Gaps timetables scored
by the same yardsticks).
"""
from __future__ import annotations

import argparse
import copy
import csv
import json
from pathlib import Path

import yaml

from riverline.line import Line, hhmm, to_min
from riverline.model import TimetableModel
from riverline.report import evaluate, write_outputs
from riverline.solve import optimize

HERE = Path(__file__).parent


def baseline_departures(line: Line, annulled: bool) -> dict:
    """Full-length WEC->Trenton and Trenton->WEC trips of the 2013 timetable."""
    tt = json.loads((HERE / "data/timetable_2013.json").read_text())
    drop = set(tt["annulled_in_gaps_files"]) if annulled else set()
    dep = {"N": [], "S": []}
    for t in tt["trips"]:
        num = t["train"].split()[-1].replace("X", "")
        if num in drop:
            continue
        first, last = t["stops"][0]["station"], t["stops"][-1]["station"]
        if t["dir"] == "N" and first == "WEC" and last == "Trenton":
            dep["N"].append(to_min(t["stops"][0]["time"]))
        if t["dir"] == "S" and first == "Trenton" and last == "WEC":
            dep["S"].append(to_min(t["stops"][0]["time"]))
    return dep


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(HERE / "config.yaml"))
    ap.add_argument("--fleet", type=int, nargs="*", help="run one scenario per fleet size")
    ap.add_argument("--name", default=None)
    args = ap.parse_args()

    cfg = yaml.safe_load(open(args.config))
    line = Line(HERE / "data/line.json")
    demand = TimetableModel(line, cfg, candidates={"N": [], "S": []}).demand
    outdir = HERE / "outputs"
    rows = []

    for label, ann in (("NJT 2013 full (10 trains)", False), ("NJT Gaps (8 trains, annulled)", True)):
        dep = baseline_departures(line, ann)
        met, _ = evaluate(line, cfg, dep, demand)
        rows.append({"scenario": label, **met})

    fleets = sorted(args.fleet or [cfg["constraints"]["fleet"]["vehicles"]])
    seed = None                       # each fleet size starts from the previous answer
    for n in fleets:
        c = copy.deepcopy(cfg)
        c["constraints"]["fleet"]["vehicles"] = n
        name = args.name or f"optimized_{n}_LRV"
        print(f"Scenario {name}")
        m = optimize(line, c, seed=seed)
        dep = m.departures()
        seed = dep
        met, blocks = evaluate(line, c, dep, demand)
        met["solver_status"] = m.solution.status
        met["solve_seconds"] = round(getattr(m, "elapsed", m.solution.seconds))
        write_outputs(outdir / name, line, dep, met, blocks)
        (outdir / name / "departures.json").write_text(json.dumps(
            {d: [hhmm(t) for t in dep[d]] for d in dep}, indent=1))
        rows.append({"scenario": name, **met})
        print("  ", {k: met[k] for k in ("trips", "avg_wait_per_rider_min", "cars_needed", "single_track_conflicts")})

    keys = ["scenario", "trips", "rider_wait_minutes", "avg_wait_per_rider_min", "max_gap_min",
            "avg_headway_AM_peak_6_9", "avg_headway_midday_9_15", "avg_headway_PM_peak_15_1830",
            "cars_needed", "single_track_conflicts", "solver_status", "solve_seconds"]
    outdir.mkdir(exist_ok=True)
    # merge with earlier runs: same scenario name is replaced, others are kept
    new = [{**r, "trips": f"{r['trips']['N']} NB / {r['trips']['S']} SB"} for r in rows]
    names = {r["scenario"] for r in new}
    old = []
    if (outdir / "comparison.csv").exists():
        old = [r for r in csv.DictReader(open(outdir / "comparison.csv")) if r["scenario"] not in names]
    with open(outdir / "comparison.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        for r in new[:2] + old + new[2:]:
            w.writerow(r)
    print(f"\nWrote {outdir / 'comparison.csv'}")


if __name__ == "__main__":
    main()
