"""Independent checking and reporting.

`evaluate` scores ANY set of departures (an optimised one, or NJ TRANSIT's
2013 / Gaps timetable) with the same yardsticks, so results are comparable:
riders' waiting time, headways, vehicles needed, and single-track conflicts.
It does not trust the optimiser: it rebuilds stop times and re-checks meets.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

from .line import Line, check_timetable, hhmm, to_min


def stop_trips(line: Line, dep: dict) -> list[dict]:
    trips = []
    for d in ("N", "S"):
        for k, t in enumerate(sorted(dep[d])):
            num = (200 if d == "N" else 201) + 2 * k
            trips.append({"train": str(num), "dir": d, "cars": 1,
                          "stops": [{"station": s, "time": hhmm(m)} for s, m in line.stop_times(d, t)]})
    return trips


def vehicle_blocks(line: Line, dep: dict, turn_min: dict) -> list[list[dict]]:
    """Assign cars first-in-first-out at each terminal; returns one list of
    trips per car. len(result) = cars needed."""
    events = sorted([(t, "N") for t in dep["N"]] + [(t, "S") for t in dep["S"]])
    origin = {"N": "WEC", "S": "Trenton"}
    dest = {"N": "Trenton", "S": "WEC"}
    turn = {"WEC": turn_min["WEC"], "Trenton": turn_min["Trenton"]}
    waiting = {"WEC": [], "Trenton": []}          # (ready_minute, car_id)
    cars: list[list[dict]] = []
    for t, d in events:
        o = origin[d]
        ready = sorted(waiting[o])
        pick = next((c for c in ready if c[0] <= t), None)
        if pick:
            waiting[o].remove(pick)
            cid = pick[1]
        else:
            cid = len(cars)
            cars.append([])
        arr = t + line.run_time[d]
        cars[cid].append({"dir": d, "dep": t, "arr": arr})
        waiting[dest[d]].append((arr + turn[dest[d]], cid))
    return cars


def cars_in_use(blocks, t0, t1):
    out = []
    for m in range(t0, t1 + 1):
        n = 0
        for b in blocks:
            if b and b[0]["dep"] <= m < b[-1]["arr"]:
                n += 1
        out.append(n)
    return out


def evaluate(line: Line, cfg: dict, dep: dict, demand_fn) -> dict:
    """demand_fn(direction, minute) -> riders per minute."""
    turn = cfg["constraints"]["fleet"]["turn_min"] if cfg["constraints"].get("fleet") else {"WEC": 6, "Trenton": 5}
    out = {"trips": {d: len(dep[d]) for d in dep}}
    wait = riders = 0.0
    gaps_all = {}
    for d in ("N", "S"):
        ts = sorted(dep[d])
        gaps = [(a, b - a) for a, b in zip(ts, ts[1:])]
        gaps_all[d] = gaps
        for a, g in gaps:
            r = demand_fn(d, a + g / 2)
            wait += r * g * g / 2
            riders += r * g
    out["rider_wait_minutes"] = round(wait)
    out["avg_wait_per_rider_min"] = round(wait / riders, 2) if riders else None
    out["max_gap_min"] = max(g for d in gaps_all for _, g in gaps_all[d])

    def avg_headway(f, t):
        gs = [g for d in gaps_all for a, g in gaps_all[d] if to_min(f) <= a < to_min(t)]
        return round(sum(gs) / len(gs), 1) if gs else None
    out["avg_headway_AM_peak_6_9"] = avg_headway("06:00", "09:00")
    out["avg_headway_midday_9_15"] = avg_headway("09:00", "15:00")
    out["avg_headway_PM_peak_15_1830"] = avg_headway("15:00", "18:30")
    blocks = vehicle_blocks(line, dep, turn)
    out["cars_needed"] = len(blocks)
    out["single_track_conflicts"] = len(check_timetable(line, stop_trips(line, dep), 0))
    return out, blocks


def write_outputs(folder: Path, line: Line, dep: dict, metrics: dict, blocks) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    trips = stop_trips(line, dep)
    with open(folder / "timetable.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["train", "direction", "car"] + line.stations)
        car_of = {}
        for cid, b in enumerate(blocks):
            for leg in b:
                car_of[(leg["dir"], leg["dep"])] = cid + 1
        for t in trips:
            times = {s["station"]: s["time"] for s in t["stops"]}
            d = t["dir"]
            car = car_of.get((d, to_min(t["stops"][0]["time"])), "")
            w.writerow([t["train"], "NB" if d == "N" else "SB", car] + [times.get(s, "") for s in line.stations])
    with open(folder / "vehicle_blocks.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["car", "trip order", "direction", "depart", "arrive"])
        for cid, b in enumerate(blocks):
            for k, leg in enumerate(b):
                w.writerow([cid + 1, k + 1, "NB" if leg["dir"] == "N" else "SB", hhmm(leg["dep"]), hhmm(leg["arr"])])
    (folder / "summary.json").write_text(json.dumps(metrics, indent=2))
