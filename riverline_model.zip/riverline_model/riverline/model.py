"""River LINE weekday timetable optimisation model.

Decision: which minutes to dispatch a train
    northbound from WEC   -> x["N"][t] in {0,1}
    southbound from Trenton -> x["S"][t] in {0,1}

Core structure (always built)
    Each direction's departures form one ordered sequence (a path through
    the candidate minutes). Arc y[i->j] = 1 means "j is the next departure
    after i", so every gap between trains is a variable we can price and
    limit. This is what lets the objective measure rider waiting time.

Everything else - fleet size, single-track meets, policy limits, crew
limits, track work - is a *pluggable constraint* registered with
@constraint("name") in constraints.py and switched on in config.yaml.
Objective pieces work the same way with @objective("name").
"""
from __future__ import annotations

import math
from collections import defaultdict

from .line import Line, hhmm, to_min
from .milp import MILP

CONSTRAINTS: dict = {}
OBJECTIVES: dict = {}


def constraint(name):
    def deco(fn):
        CONSTRAINTS[name] = fn
        return fn
    return deco


def objective(name):
    def deco(fn):
        OBJECTIVES[name] = fn
        return fn
    return deco


def step_value(schedule, minute, default=None):
    """schedule = [{"from": "HH:MM", <key>: value}, ...]; return the entry in force."""
    cur = default
    for row in sorted(schedule, key=lambda r: to_min(r["from"])):
        if to_min(row["from"]) <= minute:
            cur = row
    return cur


class TimetableModel:
    DIRS = ("N", "S")
    ORIGIN = {"N": "WEC", "S": "Trenton"}
    DEST = {"N": "Trenton", "S": "WEC"}

    def __init__(self, line: Line, cfg: dict, candidates: dict | None = None):
        self.line, self.cfg = line, cfg
        self.lp = MILP()
        self.step = int(cfg.get("time_step", 1))
        sv = cfg["service"]
        self.window = (to_min(sv["window_start"]), to_min(sv["window_end"]))
        self.run = line.run_time
        # candidate departure minutes: the whole trip must fit inside the window
        if candidates is None:
            candidates = {d: range(self.window[0], self.window[1] - self.run[d] + 1, self.step)
                          for d in self.DIRS}
        self.times = {d: sorted(t for t in set(candidates[d])
                                if self.window[0] <= t <= self.window[1] - self.run[d])
                      for d in self.DIRS}
        self.x = {d: {t: self.lp.binary(f"x_{d}_{hhmm(t)}") for t in self.times[d]} for d in self.DIRS}
        self.arcs = {d: {} for d in self.DIRS}          # (i, j) -> var ; i/j may be "src"/"snk"
        self.notes: list[str] = []
        self.extra: dict = {}                           # constraints can stash data for reporting

    # ---------------------------------------------------------------- core
    def _build_sequences(self):
        sv, hw = self.cfg["service"], self.cfg["headways"]
        first_by, last_after = to_min(sv["first_departure_by"]), to_min(sv["last_departure_after"])
        hmin = int(hw["min"])
        for d in self.DIRS:
            T = self.times[d]
            for i in T:
                hmax = int(step_value(hw["max"], i, {"minutes": 60})["minutes"])
                for j in T:
                    g = j - i
                    if hmin <= g <= hmax:
                        self.arcs[d][(i, j)] = self.lp.binary(f"y_{d}_{hhmm(i)}_{hhmm(j)}")
                if i <= first_by:
                    self.arcs[d][("src", i)] = self.lp.binary(f"y_{d}_src_{hhmm(i)}")
                if i >= last_after:
                    self.arcs[d][(i, "snk")] = self.lp.binary(f"y_{d}_{hhmm(i)}_snk")
            ins, outs = defaultdict(dict), defaultdict(dict)
            for (i, j), v in self.arcs[d].items():
                outs[i][v] = 1
                ins[j][v] = 1
            self.lp.eq(outs["src"], 1, f"{d}_one_first_train")
            self.lp.eq(ins["snk"], 1, f"{d}_one_last_train")
            for t in T:
                self.lp.eq({**ins[t], self.x[d][t]: -1}, 0, f"{d}_in_{hhmm(t)}")
                self.lp.eq({**outs[t], self.x[d][t]: -1}, 0, f"{d}_out_{hhmm(t)}")

    def build(self):
        from . import constraints, objectives  # noqa: F401  (registers plug-ins)
        self._build_sequences()
        for name, params in (self.cfg.get("constraints") or {}).items():
            if params is False or params is None:
                continue
            if name not in CONSTRAINTS:
                raise KeyError(f"unknown constraint '{name}'. Known: {sorted(CONSTRAINTS)}")
            CONSTRAINTS[name](self, **(params if isinstance(params, dict) else {}))
        for name, params in (self.cfg.get("objective") or {}).items():
            if params is False or params is None:
                continue
            OBJECTIVES[name](self, **(params if isinstance(params, dict) else {}))
        return self

    # ------------------------------------------------------------- solve
    def solve(self):
        s = self.cfg.get("solver", {})
        self.solution = self.lp.solve(time_limit=s.get("time_limit_sec", 120),
                                      mip_gap=s.get("mip_gap", 1e-3),
                                      verbose=s.get("verbose", False),
                                      backend=s.get("backend", "highs"),
                                      threads=s.get("threads"))
        return self.solution

    def warm_start(self, dep: dict) -> None:
        """Give the solver a known schedule to start from (used by Gurobi;
        HiGHS ignores it). dep = {"N": [minutes], "S": [minutes]}."""
        for d in self.DIRS:
            chosen = sorted(t for t in dep.get(d, []) if t in self.x[d])
            on = set(chosen)
            for t, v in self.x[d].items():
                self.lp.set_start(v, 1 if t in on else 0)
            pairs = set(zip(chosen, chosen[1:]))
            if chosen:
                pairs |= {("src", chosen[0]), (chosen[-1], "snk")}
            for key, v in self.arcs[d].items():
                self.lp.set_start(v, 1 if key in pairs else 0)

    def departures(self) -> dict:
        sol = self.solution
        return {d: [t for t, v in self.x[d].items() if sol[v] > 0.5] for d in self.DIRS}

    # ----------------------------------------------------------- helpers
    def demand(self, d: str, minute: float) -> float:
        """Riders per minute wanting direction d at this minute (config 'demand')."""
        prof = self.cfg["demand"][d]
        cur = 0.0
        for f, rph in sorted(prof, key=lambda r: to_min(r[0])):
            if to_min(f) <= minute:
                cur = rph
        return cur / 60.0

    def grid_index(self, minute: float) -> int:
        """Minute-resolution index used by time-indexed constraints (e.g. fleet)."""
        return math.ceil(minute - self.window[0])
