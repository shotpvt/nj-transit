"""Solution strategy.

`direct`          one solve on the full 1-minute grid. Slow with HiGHS for tight
                  fleets; worth trying with backend: gurobi.
`coarse_to_fine`  (default)
    1. Starting schedule: the best of
         - a coarse solve on a 5-min grid for each southbound shift 0..4,
         - a `seed` passed in (e.g. the answer for one fewer LRV),
         - a simple 30-minute pattern that respects the meets (always available).
    2. Polish: every departure may move +/- `refine_window` minutes.
    3. Rolling windows: free up `window_hours` of the day at a time (any
       1-minute departure inside it, everything outside fixed in place),
       re-optimise, slide on; repeat passes until nothing improves.
    Small sub-problems solve in seconds. This is a heuristic (large
    neighbourhood search): very good schedules, not a proof of optimality.
"""
from __future__ import annotations

import copy
import time

from .line import Line, to_min
from .model import TimetableModel


def _solve(line, cfg, cand, limit, start=None):
    c2 = copy.deepcopy(cfg)
    c2.setdefault("solver", {})["time_limit_sec"] = limit
    m = TimetableModel(line, c2, candidates=cand).build()
    if start:
        m.warm_start(start)       # Gurobi starts from the current best schedule
    m.solve()
    return m


def _better(a, b):
    if b is None or b.solution.values is None:
        return a
    if a is None or a.solution.values is None:
        return b
    return b if b.solution.objective < a.solution.objective - 1e-6 else a


def periodic_seed(line: Line, cfg: dict, headway: int = 30) -> dict | None:
    """A plain every-`headway`-minutes timetable whose meets all fall in passing track."""
    sv = cfg["service"]
    lo, hi = to_min(sv["window_start"]), to_min(sv["window_end"])
    buf = (cfg.get("constraints") or {}).get("single_track") or {}
    bad = line.forbidden_offsets(buf.get("buffer_min", 0) if isinstance(buf, dict) else 0)
    for startN in range(to_min(sv["first_departure_by"]), lo - 1, -1):
        for off in range(-headway, headway):
            if all((off + headway * k) not in bad for k in range(-12, 13)):
                N = list(range(startN, hi - line.run_time["N"] + 1, headway))
                s0 = startN + off
                while s0 - headway >= lo:
                    s0 -= headway
                S = list(range(s0, hi - line.run_time["S"] + 1, headway))
                fb, la = to_min(sv["first_departure_by"]), to_min(sv["last_departure_after"])
                if S and S[0] <= fb and S[-1] >= la and N[0] <= fb and N[-1] >= la:
                    return {"N": N, "S": S}
    return None


def optimize(line: Line, cfg: dict, log=print, seed: dict | None = None) -> TimetableModel:
    s = cfg.get("solver", {})
    if s.get("strategy", "coarse_to_fine") == "direct":
        m = TimetableModel(line, cfg).build()
        m.solve()
        return m

    cs = int(s.get("coarse_step", 5))
    w = int(s.get("refine_window", 3))
    lo, hi = to_min(cfg["service"]["window_start"]), to_min(cfg["service"]["window_end"])
    t0 = time.time()
    fmt = lambda m: "-" if m.solution.objective is None else round(m.solution.objective)

    # 1. starting schedule ------------------------------------------------
    best = None
    for phase in s.get("coarse_phases", list(range(cs))):
        m = _solve(line, cfg, {"N": range(lo, hi + 1, cs), "S": range(lo + phase, hi + 1, cs)},
                   s.get("coarse_time_limit_sec", 20))
        log(f"  coarse grid {cs} min, SB shift {phase}: {m.solution.status}, wait = {fmt(m)}")
        best = _better(best, m)
    for label, sd in (("seed (previous answer)", seed), ("30-min pattern", periodic_seed(line, cfg))):
        if sd:
            m = _solve(line, cfg, sd, 30, start=sd)
            log(f"  {label}: {m.solution.status}, wait = {fmt(m)}")
            best = _better(best, m)
    if best is None or best.solution.values is None:
        raise RuntimeError("No feasible starting schedule - loosen constraints "
                           "(fleet, headways, span) or raise coarse_time_limit_sec.")

    # 2. polish: +/- w minutes around every departure --------------------
    dep = best.departures()
    m = _solve(line, cfg, {d: {t + k for t in dep[d] for k in range(-w, w + 1)} for d in "NS"},
               s.get("refine_time_limit_sec", 60), start=dep)
    log(f"  polish +/-{w} min: {m.solution.status}, wait = {fmt(m)}")
    best = _better(best, m)

    # 3. rolling windows ---------------------------------------------------
    span = int(60 * s.get("window_hours", 3))
    slide = int(60 * s.get("window_slide_hours", 2))
    for p in range(int(s.get("window_passes", 2))):
        improved = False
        for a in range(lo, hi, slide):
            dep = best.departures()
            cand = {d: {t for t in dep[d] if not (a <= t < a + span)} | set(range(a, a + span))
                    for d in "NS"}
            m = _solve(line, cfg, cand, s.get("window_time_limit_sec", 30), start=dep)
            nb = _better(best, m)
            if nb is not best:
                improved = True
                log(f"  window pass {p + 1}, {a // 60:02d}:{a % 60:02d}+{span // 60}h: wait = {fmt(nb)}")
            best = nb
        if not improved:
            break
    best.elapsed = time.time() - t0
    return best
