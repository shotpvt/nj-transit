"""Pluggable constraints.

To add a constraint:
  1. write a function  `def my_rule(m, **params)`  decorated with
     @constraint("my_rule")
  2. inside, add linear rows with  m.lp.add({var: coef, ...}, lb=.., ub=..)
     using the model's variables:
        m.x[d][t]      1 if a train departs direction d ("N"/"S") at minute t
        m.arcs[d][(i,j)]  1 if j is the next departure after i
        m.times[d]     candidate departure minutes
  3. switch it on in config.yaml under `constraints:` with its parameters.

Nothing else in the code needs to change.
"""
from __future__ import annotations

from .line import hhmm, to_min
from .model import constraint, step_value


@constraint("fleet")
def fleet(m, vehicles: int, turn_min: dict, availability: list | None = None,
          start_at: dict | None = None):
    """Vehicle balance at each terminal, minute by minute.

    A train that arrives at Trenton can leave southbound only after
    `turn_min["Trenton"]` minutes (same for WEC). Idle vehicles wait at the
    terminal (or the nearby yard: CLRC by 36th St., TLF at Trenton).
    `vehicles` = LRVs available at the start of the day (all run as 1-car trains).
    `availability` (optional) = [{"from": "HH:MM", "vehicles": n}, ...] lowers the
    count during the day (e.g. a breakdown at 15:00): withdrawn cars must sit idle.
    `start_at` (optional) = {"WEC": a, "Trenton": b} fixes where cars start.
    """
    lp = m.lp
    n_steps = m.grid_index(m.window[1]) + 1
    W0 = lp.var("vehicles_start_WEC", 0, vehicles, integer=True)
    T0 = lp.var("vehicles_start_Trenton", 0, vehicles, integer=True)
    lp.eq({W0: 1, T0: 1}, vehicles, "fleet_size")
    if start_at:
        lp.fix(W0, start_at.get("WEC", 0)); lp.fix(T0, start_at.get("Trenton", 0))
    IW = [lp.var(f"idle_WEC_{k}", 0, vehicles) for k in range(n_steps)]
    IT = [lp.var(f"idle_TRE_{k}", 0, vehicles) for k in range(n_steps)]
    arrive = {"WEC": [dict() for _ in range(n_steps)], "Trenton": [dict() for _ in range(n_steps)]}
    for t, v in m.x["N"].items():                     # NB trips free a car at Trenton
        k = m.grid_index(t + m.run["N"] + turn_min["Trenton"])
        if k < n_steps:
            arrive["Trenton"][k][v] = arrive["Trenton"][k].get(v, 0) + 1
    for t, v in m.x["S"].items():                     # SB trips free a car at WEC
        k = m.grid_index(t + m.run["S"] + turn_min["WEC"])
        if k < n_steps:
            arrive["WEC"][k][v] = arrive["WEC"][k].get(v, 0) + 1
    depart = {"WEC": {m.grid_index(t): v for t, v in m.x["N"].items()},
              "Trenton": {m.grid_index(t): v for t, v in m.x["S"].items()}}
    for term, I, I0 in (("WEC", IW, W0), ("Trenton", IT, T0)):
        for k in range(n_steps):
            row = {I[k]: 1, (I[k - 1] if k else I0): -1}
            for v, c in arrive[term][k].items():
                row[v] = row.get(v, 0) - c
            if k in depart[term]:
                row[depart[term][k]] = row.get(depart[term][k], 0) + 1
            lp.eq(row, 0, f"balance_{term}_{k}")
    if availability:
        for k in range(n_steps):
            minute = m.window[0] + k * m.step
            row = step_value(availability, minute)
            if row and row["vehicles"] < vehicles:
                lp.add({IW[k]: 1, IT[k]: 1}, lb=vehicles - row["vehicles"], name=f"withdrawn_{k}")
    # Valid tightening rows (speed the solver up a lot): one car can make at most
    # one departure per direction per round trip, so any window as long as a
    # round trip holds at most `vehicles` departures each way.
    cycle = m.run["N"] + turn_min["Trenton"] + m.run["S"] + turn_min["WEC"]
    for d in m.DIRS:
        T = m.times[d]
        for a in T:
            row = {m.x[d][t]: 1 for t in T if a <= t < a + cycle}
            lp.add(row, ub=vehicles, name=f"cycle_cut_{d}_{a}")
    m.extra["fleet"] = {"vehicles": vehicles, "turn_min": turn_min, "idle_WEC": IW, "idle_TRE": IT}


@constraint("single_track")
def single_track(m, buffer_min: float = 0.0):
    """Opposing trains may not be on the same single-track block at the same
    time (+ `buffer_min` clearance). Uses the passing sections in data/line.json.
    Rows are grouped: SB departures within one min-headway window are already
    mutually exclusive, so  x_N[a] + sum(x_S in window) <= 1  is valid and tighter."""
    bad = sorted(m.line.forbidden_offsets(buffer_min, m.step))
    hmin = int(m.cfg["headways"]["min"])
    # split forbidden offsets into runs shorter than the minimum headway
    runs, cur = [], []
    for d in bad:
        if cur and (d != cur[-1] + 1 or d - cur[0] >= hmin):
            runs.append(cur); cur = []
        cur.append(d)
    if cur:
        runs.append(cur)
    xs = m.x["S"]
    for a, va in m.x["N"].items():
        for run in runs:
            row = {va: 1}
            for d in run:
                if (a + d) in xs:
                    row[xs[a + d]] = 1
            if len(row) > 1:
                m.lp.add(row, ub=1, name=f"meet_{hhmm(a)}_{run[0]}")
    m.extra["forbidden_offsets"] = bad


@constraint("max_trips")
def max_trips(m, per_direction: int):
    """Budget limit, e.g. operator hours: at most n departures each way."""
    for d in m.DIRS:
        m.lp.add({v: 1 for v in m.x[d].values()}, ub=per_direction, name=f"max_trips_{d}")


@constraint("required_departures")
def required_departures(m, N: list | None = None, S: list | None = None):
    """Force specific departures, e.g. a timed connection at Trenton."""
    for d, lst in (("N", N or []), ("S", S or [])):
        for hh in lst:
            t = to_min(hh)
            if t not in m.x[d]:
                raise ValueError(f"{hh} is not a candidate {d} departure")
            m.lp.fix(m.x[d][t], 1)


@constraint("no_departures")
def no_departures(m, windows: list):
    """Block departures in a time window, e.g. track work: [{dir, from, to}]."""
    for w in windows:
        for d in ([w["dir"]] if w.get("dir") in ("N", "S") else m.DIRS):
            for t, v in m.x[d].items():
                if to_min(w["from"]) <= t < to_min(w["to"]):
                    m.lp.fix(v, 0)


@constraint("min_trips_in_period")
def min_trips_in_period(m, periods: list):
    """Service standard: at least n departures each way in a window,
    e.g. [{from: "06:00", to: "09:00", trips: 10}]."""
    for p in periods:
        for d in m.DIRS:
            row = {v: 1 for t, v in m.x[d].items() if to_min(p["from"]) <= t < to_min(p["to"])}
            m.lp.add(row, lb=p["trips"], name=f"min_trips_{d}_{p['from']}")
