"""Physical line data: stations, mileposts, passing track, run-time profiles.

Everything about *where* trains can pass lives here. The model only asks one
question of this module: "if a northbound train leaves WEC at minute a and a
southbound train leaves Trenton at minute a + d, do they ever meet on single
track?"  That answer depends only on the offset d, so we compute the set of
forbidden offsets once and reuse it.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


def hhmm(minute: float) -> str:
    m = int(round(minute))
    return f"{m // 60:02d}:{m % 60:02d}"


def to_min(text) -> int:
    if isinstance(text, (int, float)):      # YAML turns unquoted 05:30 into 330 (minutes)
        return int(text)
    h, m = text.split(":")
    return int(h) * 60 + int(m)


@dataclass
class Block:
    """A stretch of single track between two passing sections."""
    name: str
    from_mp: float
    to_mp: float


class Line:
    def __init__(self, path: str | Path):
        d = json.loads(Path(path).read_text())
        self.stations = [s["name"] for s in d["stations"]]
        self.mp = {s["name"]: s["milepost"] for s in d["stations"]}
        self.passing = d["passing_sections"]
        self.profile = {"N": d["run_profile_NB"], "S": d["run_profile_SB"]}
        self.run_time = {k: v[-1]["minute"] for k, v in self.profile.items()}
        self.blocks = self._single_track_blocks()

    # ---- geometry -------------------------------------------------------
    def _single_track_blocks(self) -> list[Block]:
        ps = sorted(self.passing, key=lambda p: p["from_mp"])
        out = []
        for a, b in zip(ps, ps[1:]):
            if b["from_mp"] > a["to_mp"]:
                out.append(Block(f"{a['name']} -> {b['name']}", a["to_mp"], b["from_mp"]))
        return out

    def time_at_mp(self, direction: str, mp: float) -> float:
        """Minutes after departure at which a train passes milepost `mp`
        (linear between scheduled station times)."""
        pts = [(self.mp[p["station"]], p["minute"]) for p in self.profile[direction]]
        if direction == "S":
            pts = sorted(pts)            # increasing milepost
        for (m1, t1), (m2, t2) in zip(pts, pts[1:]):
            lo, hi = min(m1, m2), max(m1, m2)
            if lo <= mp <= hi:
                return t1 if m2 == m1 else t1 + (t2 - t1) * (mp - m1) / (m2 - m1)
        raise ValueError(f"milepost {mp} outside profile")

    def occupancy(self, direction: str) -> list[tuple[float, float]]:
        """(enter, exit) minutes after departure for every single-track block."""
        occ = []
        for b in self.blocks:
            t1, t2 = self.time_at_mp(direction, b.from_mp), self.time_at_mp(direction, b.to_mp)
            occ.append((min(t1, t2), max(t1, t2)))
        return occ

    def forbidden_offsets(self, buffer: float, step: int = 1) -> set[int]:
        """Offsets d (SB departure minus NB departure, in minutes) that put an
        opposing pair on the same single-track block at the same time.
        `buffer` = extra clearance minutes required between the two trains."""
        occN, occS = self.occupancy("N"), self.occupancy("S")
        bad = set()
        lo = -int(self.run_time["S"]) - 5
        hi = int(self.run_time["N"]) + 5
        for d in range(lo, hi + 1):
            for (inN, outN), (inS, outS) in zip(occN, occS):
                # NB occupies [inN, outN]; SB occupies [d+inS, d+outS]
                if d + inS < outN + buffer and d + outS > inN - buffer:
                    bad.add(d)
                    break
        return bad

    def stop_times(self, direction: str, depart: float) -> list[tuple[str, float]]:
        return [(p["station"], depart + p["minute"]) for p in self.profile[direction]]


# ---- checking any timetable (e.g. the 2013 one) --------------------------
def check_timetable(line: Line, trips: list[dict], buffer: float = 0.0) -> list[dict]:
    """Return every opposing pair that shares a single-track block.
    `trips` = [{"train", "dir", "stops": [{"station","time"}...]}]"""
    def interp(points, mp):
        for (m1, t1), (m2, t2) in zip(points, points[1:]):
            lo, hi = min(m1, m2), max(m1, m2)
            if lo <= mp <= hi:
                return t1 if m1 == m2 else t1 + (t2 - t1) * (mp - m1) / (m2 - m1)
        return None

    occ = []
    for t in trips:
        pts = [(line.mp[s["station"]], to_min(s["time"])) for s in t["stops"]]
        if len(pts) < 2:
            continue
        blocks = []
        for i, b in enumerate(line.blocks):
            ta, tb = interp(pts, b.from_mp), interp(pts, b.to_mp)
            if ta is not None and tb is not None:
                blocks.append((i, min(ta, tb), max(ta, tb)))
        occ.append((t, blocks))
    conflicts = []
    nb = [o for o in occ if o[0]["dir"] == "N"]
    sb = [o for o in occ if o[0]["dir"] == "S"]
    for tn, bn in nb:
        for ts, bs in sb:
            for (i, a1, a2) in bn:
                for (j, b1, b2) in bs:
                    if i == j and b1 < a2 + buffer and b2 > a1 - buffer:
                        conflicts.append({"nb": tn["train"], "sb": ts["train"],
                                          "block": line.blocks[i].name,
                                          "time": hhmm(max(a1, b1))})
    return conflicts
