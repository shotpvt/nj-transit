"""Pluggable objective terms (all minimised, in rider-minutes).

Add one the same way as a constraint: decorate with @objective("name"),
add costs with  m.lp.cost(var, coefficient), switch it on in config.yaml.
"""
from __future__ import annotations

from .model import objective


@objective("rider_wait")
def rider_wait(m, weight: float = 1.0):
    """Expected waiting time. Riders turn up at random, so a gap of g minutes
    with demand rate r riders/min costs r * g^2 / 2 rider-minutes."""
    for d in m.DIRS:
        for (i, j), v in m.arcs[d].items():
            if i == "src" or j == "snk":
                continue
            g = j - i
            r = m.demand(d, (i + j) / 2)
            m.lp.cost(v, weight * r * g * g / 2)


@objective("trip_cost")
def trip_cost(m, rider_minutes_per_trip: float = 0.0):
    """Operating cost of a trip, expressed in rider-minutes so it trades off
    against waiting time (0 = run as much service as the fleet allows)."""
    for d in m.DIRS:
        for v in m.x[d].values():
            m.lp.cost(v, rider_minutes_per_trip)


@objective("regularity")
def regularity(m, weight: float = 1.0, target_min: float = 15):
    """Optional: penalise gaps longer than a target headway (linear per minute over)."""
    for d in m.DIRS:
        for (i, j), v in m.arcs[d].items():
            if i == "src" or j == "snk":
                continue
            over = max(0, (j - i) - target_min)
            if over:
                m.lp.cost(v, weight * over)
