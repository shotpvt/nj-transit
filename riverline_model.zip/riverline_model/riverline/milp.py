"""A very small modelling layer with two solver back-ends:

    backend="highs"   scipy.optimize.milp (HiGHS) - free, ships with SciPy
    backend="gurobi"  Gurobi via gurobipy - needs `pip install gurobipy` and a
                      licence (free academic licences: gurobi.com/academia).
                      Without a full licence gurobipy only solves tiny models.

Gurobi also accepts a warm start (`lp.set_start(var, value)`), which the
coarse-to-fine strategy uses to start each refinement from the best schedule.

Why not PuLP/Pyomo? They may not be installed everywhere. This layer has the
same shape (add variables, add linear constraints, add objective terms), so a
model written against it can be ported to PuLP or Gurobi by swapping this file.

    lp = MILP()
    x = lp.var("x", lb=0, ub=1, integer=True)
    lp.add({x: 1, y: 1}, ub=1, name="conflict")     # x + y <= 1
    lp.cost(x, 5.0)                                   # minimise 5x
    sol = lp.solve(time_limit=60)
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix


@dataclass
class Solution:
    status: str
    objective: float | None
    values: np.ndarray | None
    seconds: float
    gap: float | None = None

    def __getitem__(self, var: int) -> float:
        return float(self.values[var])


@dataclass
class MILP:
    names: list = field(default_factory=list)
    lb: list = field(default_factory=list)
    ub: list = field(default_factory=list)
    integer: list = field(default_factory=list)
    c: list = field(default_factory=list)
    rows: list = field(default_factory=list)       # (dict var->coef, lb, ub, name)
    constant: float = 0.0
    start: dict = field(default_factory=dict)      # var -> warm-start value (Gurobi only)

    def var(self, name: str, lb: float = 0, ub: float = np.inf, integer: bool = False) -> int:
        self.names.append(name)
        self.lb.append(lb)
        self.ub.append(ub)
        self.integer.append(1 if integer else 0)
        self.c.append(0.0)
        return len(self.names) - 1

    def binary(self, name: str) -> int:
        return self.var(name, 0, 1, True)

    def add(self, coefs: dict, lb: float = -np.inf, ub: float = np.inf, name: str = "") -> None:
        if coefs:
            self.rows.append((coefs, lb, ub, name))

    def eq(self, coefs: dict, rhs: float, name: str = "") -> None:
        self.add(coefs, rhs, rhs, name)

    def cost(self, var: int, coef: float) -> None:
        self.c[var] += coef

    def set_start(self, var: int, value: float) -> None:
        self.start[var] = value

    def fix(self, var: int, value: float) -> None:
        self.lb[var] = value
        self.ub[var] = value

    @property
    def size(self) -> str:
        return f"{len(self.names):,} variables, {len(self.rows):,} constraints"

    def _matrix(self):
        r, cidx, v = [], [], []
        lo, hi = [], []
        for i, (coefs, l, u, _) in enumerate(self.rows):
            for var, a in coefs.items():
                r.append(i); cidx.append(var); v.append(a)
            lo.append(l); hi.append(u)
        A = coo_matrix((v, (r, cidx)), shape=(len(self.rows), len(self.names))).tocsr()
        return A, np.array(lo, dtype=float), np.array(hi, dtype=float)

    def solve(self, time_limit: float = 120, mip_gap: float = 1e-4, verbose: bool = False,
              backend: str = "highs", threads: int | None = None) -> Solution:
        if backend == "gurobi":
            try:
                import gurobipy  # noqa: F401
            except ImportError:
                print("  ! gurobipy is not installed - falling back to HiGHS "
                      "(pip install gurobipy, plus a Gurobi licence)")
                backend = "highs"
        if backend == "gurobi":
            return self._solve_gurobi(time_limit, mip_gap, verbose, threads)
        return self._solve_highs(time_limit, mip_gap, verbose)

    def _solve_highs(self, time_limit, mip_gap, verbose) -> Solution:
        A, lo, hi = self._matrix()
        t0 = time.time()
        res = milp(c=np.array(self.c), integrality=np.array(self.integer),
                   bounds=Bounds(np.array(self.lb), np.array(self.ub)),
                   constraints=[LinearConstraint(A, lo, hi)] if self.rows else [],
                   options={"time_limit": time_limit, "mip_rel_gap": mip_gap, "disp": verbose})
        sec = time.time() - t0
        status = {0: "optimal", 1: "time limit (best found)", 2: "infeasible", 3: "unbounded", 4: "other"}.get(res.status, str(res.status))
        if res.x is None:
            return Solution(status, None, None, sec)
        return Solution(status, float(res.fun) + self.constant, res.x, sec,
                        getattr(res, "mip_gap", None))

    def _solve_gurobi(self, time_limit, mip_gap, verbose, threads) -> Solution:
        import gurobipy as gp
        from gurobipy import GRB
        A, lo, hi = self._matrix()
        n = len(self.names)
        lb = np.array(self.lb, dtype=float)
        ub = np.array(self.ub, dtype=float)
        vtype = np.array([(GRB.BINARY if (lb[k] >= 0 and ub[k] <= 1) else GRB.INTEGER) if self.integer[k]
                 else GRB.CONTINUOUS for k in range(n)])
        t0 = time.time()
        with gp.Env(empty=True) as env:
            env.setParam("OutputFlag", 1 if verbose else 0)
            env.start()
            with gp.Model("riverline", env=env) as g:
                x = g.addMVar(n, lb=np.where(np.isinf(lb), -GRB.INFINITY, lb),
                              ub=np.where(np.isinf(ub), GRB.INFINITY, ub), vtype=vtype)
                # split ranged rows into ==, <=, >= blocks
                eq = np.isfinite(lo) & np.isfinite(hi) & (lo == hi)
                le = np.isfinite(hi) & ~eq
                ge = np.isfinite(lo) & ~eq
                if eq.any():
                    g.addConstr(A[eq] @ x == lo[eq])
                if le.any():
                    g.addConstr(A[le] @ x <= hi[le])
                if ge.any():
                    g.addConstr(A[ge] @ x >= lo[ge])
                g.setObjective(np.array(self.c) @ x + self.constant, GRB.MINIMIZE)
                if self.start:
                    st = np.full(n, GRB.UNDEFINED)
                    for var, val in self.start.items():
                        st[var] = val
                    x.Start = st
                g.Params.TimeLimit = time_limit
                g.Params.MIPGap = mip_gap
                if threads:
                    g.Params.Threads = threads
                g.optimize()
                sec = time.time() - t0
                st_map = {GRB.OPTIMAL: "optimal", GRB.TIME_LIMIT: "time limit (best found)",
                          GRB.INFEASIBLE: "infeasible", GRB.INF_OR_UNBD: "infeasible or unbounded",
                          GRB.UNBOUNDED: "unbounded", GRB.INTERRUPTED: "interrupted"}
                status = st_map.get(g.Status, f"gurobi status {g.Status}")
                if g.SolCount == 0:
                    return Solution(status, None, None, sec)
                gap = g.MIPGap if g.IsMIP else None
                return Solution(status, float(g.ObjVal), np.array(x.X), sec, gap)
