# River LINE weekday timetable model

Builds a weekday River LINE timetable that minimises riders' waiting time for a
given number of available LRVs, while respecting the single-track layout,
turn times at Trenton and WEC, and the passenger service window. Constraints
are plug-ins, so the model can grow as you get more data from NJ TRANSIT.

Needs Python 3.10+ with `numpy`, `scipy` (>= 1.9, includes the HiGHS MILP
solver) and `pyyaml`.

## Solver: Gurobi or HiGHS

`config.yaml` → `solver: backend:` picks the solver.

| backend | What you need | Notes |
|---|---|---|
| `gurobi` (default in config) | `pip install gurobipy` + a Gurobi licence | Free academic licence at gurobi.com/academia (activate with `grbgetkey` on campus network/VPN). The pip-only licence is limited to tiny models and will fail on this one. Uses warm starts, usually much faster. |
| `highs` | nothing extra (comes with SciPy) | Free, slower on tight fleets |

If `gurobipy` is not installed the model prints a warning and falls back to
HiGHS automatically, so the same config runs everywhere. With Gurobi you can
also try `strategy: direct` (one full 1-minute solve), which can prove an
optimal schedule instead of using the coarse-to-fine heuristic.
Optional: `threads: 4` limits Gurobi's CPU use.

```
python run.py                       # base case from config.yaml (8 LRVs)
python run.py --fleet 6 7 8 9 10    # one scenario per fleet size
python run.py --config scenarios/8_LRV_same_trips_as_gaps.yaml --name same_trips
```

Each scenario writes `outputs/<name>/`:

| File | Contents |
|---|---|
| `timetable.csv` | every trip with its time at each station and the car that runs it |
| `vehicle_blocks.csv` | each car's sequence of trips through the day |
| `departures.json` | departure minutes from WEC (NB) and Trenton (SB) |
| `summary.json` | metrics (below) |

`outputs/comparison.csv` scores every scenario **and NJ TRANSIT's 2013 and Gaps
timetables** with the same yardsticks, so the results are directly comparable.

## Files

| Path | What it is |
|---|---|
| `config.yaml` | all inputs: service window, headway policy, fleet, constraints, objective, demand, solver |
| `data/line.json` | stations + mileposts, passing sections (2018 track charts), run-time profiles (2013 trains 216/217) |
| `data/timetable_2013.json` | the 2013 weekday timetable (Rotated tab) and the 11 trips annulled in the Gaps files |
| `riverline/line.py` | geometry: single-track blocks, when each train occupies them, conflict checking |
| `riverline/model.py` | the core model + the constraint/objective registries |
| `riverline/constraints.py` | plug-in constraints (fleet, single track, trip caps, ...) |
| `riverline/objectives.py` | plug-in objective terms (rider wait, trip cost, regularity) |
| `riverline/solve.py` | solution strategy (coarse-to-fine) |
| `riverline/report.py` | independent checker + metrics + output files |
| `riverline/milp.py` | thin modelling layer: builds the matrix and solves with Gurobi (gurobipy) or HiGHS (scipy) |

## The model

**Decisions.** For every candidate minute t: `x[N][t] = 1` if a train leaves WEC
northbound at t; `x[S][t] = 1` if one leaves Trenton southbound. Every trip runs
the full line on the 2013 running times (67 min NB, 65 min SB).

**Departure sequence (core).** In each direction the chosen departures form one
ordered chain. Binary `y[d][i,j] = 1` means "j is the next departure after i".
Arcs exist only when `min headway <= j - i <= max headway(i)`, so the headway
policy is built into the network. Flow balance makes each chosen departure have
exactly one predecessor and one successor; the first train must leave by
`first_departure_by`, the last after `last_departure_after`.

**Objective.** Riders arrive at random, so a gap of g minutes with demand r
riders/min costs r·g²/2 rider-minutes of waiting:

    minimise  sum over arcs  y[d][i,j] · r_d((i+j)/2) · (j-i)² / 2   (+ optional terms)

**Constraints (plug-ins, switch on in `config.yaml`):**

| Name | What it enforces |
|---|---|
| `fleet` | Vehicle balance minute by minute at each terminal: idle cars = previous idle + arrivals (after the minimum turn time) - departures, never negative; total = fleet size. Optional `availability` withdraws cars during the day. Includes valid "one departure per car per round trip" cuts. |
| `single_track` | Opposing trains can't be on the same single-track block at the same time (+ `buffer_min`). Because running times are fixed, this reduces to a set of forbidden offsets between NB and SB departures, computed once. With buffer 0 the 2013 timetable passes (one late-evening exception), so the rule matches practice. |
| `max_trips` | At most n departures each way (e.g. operator-hour budget). |
| `required_departures` | Force specific departures (e.g. a timed connection at Trenton). |
| `no_departures` | Block a time window (e.g. track work). |
| `min_trips_in_period` | Service standard: at least n departures in a window. |

**Solution strategy.** Solved directly at 1-minute resolution, small fleets are
slow to solve. `coarse_to_fine` (default, see `riverline/solve.py`):
1. starting schedule = best of a 5-minute-grid solve (each southbound shift 0-4),
   the answer for one fewer LRV (when running several fleet sizes), and a plain
   30-minute pattern that respects the meets;
2. polish: each departure may move ±3 min;
3. rolling windows: free 3 hours of the day at a time (any 1-minute departure),
   keep the rest fixed, re-solve, slide 2 hours; repeat up to 3 passes.

It is a large-neighbourhood heuristic: very good schedules in about 5 minutes
per scenario, not a proof of global optimality.

**Metrics (`report.py`, independent of the optimiser).** Trips, total and
average rider wait, longest gap, average headway by period, cars needed
(first-in-first-out assignment at each terminal), and a re-check of single-track
conflicts from rebuilt stop times.

## Adding a constraint

Example: no more than 6 cars on the line between 10:00 and 14:00 (maintenance).

1. In `riverline/constraints.py`:

```python
@constraint("midday_cap")
def midday_cap(m, start: str, end: str, cars: int):
    """Idle cars at the two terminals must be >= fleet - cars in the window."""
    f = m.extra["fleet"]                      # built by the fleet constraint
    for k in range(m.grid_index(to_min(start)), m.grid_index(to_min(end))):
        m.lp.add({f["idle_WEC"][k]: 1, f["idle_TRE"][k]: 1},
                 lb=f["vehicles"] - cars, name=f"midday_cap_{k}")
```

2. In `config.yaml` under `constraints:` (after `fleet`, since it uses it):

```yaml
  midday_cap: {start: "10:00", end: "14:00", cars: 6}
```

That's all: `run.py` picks it up. Variables you can use: `m.x[d][t]`,
`m.arcs[d][(i, j)]`, `m.times[d]`, anything a constraint stores in `m.extra`.
Add rows with `m.lp.add({var: coef, ...}, lb=..., ub=...)`. Objective terms work
the same way in `objectives.py` with `@objective("name")` and `m.lp.cost(var, c)`.

## Assumptions and limits (good next constraints)

- **Demand is a placeholder shape.** Replace `demand:` with NJ TRANSIT ridership
  by trip and direction; the objective is only as good as this input.
- Single cars only, full-length trips only (no short turns, no 2-car trains).
- Fixed running times; no extra holding time at sidings. Allowing holds would
  open up more patterns (e.g. even 20-minute service).
- Cars start the day at the WEC end (CLRC, 36th St.) or the Trenton end (TLF);
  the Burlington yard (BCY) and pull-out trips are not modelled yet.
- Minimum turn times from the 2013 timetable (6 min WEC, 5 min Trenton).
- No crew/operator rules yet (shift lengths, breaks, relief points).
- On-time performance is not simulated. Next step: replay a schedule with random
  delays to see how lateness spreads through the meets; use `buffer_min > 0`
  to trade service for robustness.
