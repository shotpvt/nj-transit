"""Export model results for the stringline web page (viz/data_opt.json)."""
import csv
import json
import sys
from pathlib import Path

from riverline.line import Line, to_min

HERE = Path(__file__).parent
line = Line(HERE / "data/line.json")
viz_stations = json.loads(Path(sys.argv[1]).read_text())["stations"]
idx = {s: i for i, s in enumerate(viz_stations)}

rows = list(csv.DictReader(open(HERE / "outputs/comparison.csv")))
LABEL = {"8_LRV_same_trips_as_gaps": "8 LRVs, same trip count as Gaps"}
out = {"comparison": rows, "scenarios": []}
for r in rows:
    name = r["scenario"]
    folder = HERE / "outputs" / name
    if not (folder / "departures.json").exists():
        continue
    dep = json.loads((folder / "departures.json").read_text())
    car_of = {}
    for b in csv.DictReader(open(folder / "vehicle_blocks.csv")):
        car_of[(b["direction"], b["depart"])] = b["car"]
    trips = []
    for d in ("N", "S"):
        for hh in dep[d]:
            t = to_min(hh)
            pts = [[idx[s], m] for s, m in line.stop_times(d, t)]
            car = car_of.get(("NB" if d == "N" else "SB", hh), "?")
            trips.append({"id": f"{'NB' if d == 'N' else 'SB'} {hh}", "dir": d, "cars": 1,
                          "pts": pts, "next": f"car {car}", "note": ""})
    label = LABEL.get(name, name.replace("optimized_", "").replace("_LRV", " LRVs"))
    out["scenarios"].append({"key": name, "label": label, "trips": trips})
Path(sys.argv[2]).write_text(json.dumps(out))
print(len(out["scenarios"]), "scenarios exported")
